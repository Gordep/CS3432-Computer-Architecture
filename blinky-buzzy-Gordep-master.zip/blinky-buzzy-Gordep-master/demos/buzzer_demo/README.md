## Description
This program seems to just play an annoying buzz. 