#ifndef stateMachine_included
#define stateMachine_included

void state_advance();

#endif // included
