#ifndef stateMachine_included
#define stateMachine_included


void sm_fast_clock();		/* for dim */
void sm_slow_clock();		/* to change led mode */
void sm_update_led();		/* to update leds */

#endif // included
