#ifndef updater_included

#define updater_included



char updater(char allowed);



#endif
