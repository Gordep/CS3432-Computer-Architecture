#ifndef toy_included
#define toy_included

#define LED_RED BIT0
#define LED_GREEN BIT6
#define LEDS (BIT0 | BIT6)
#define S1 BIT0
#define S2 BIT1
#define S3 BIT2
#define S4 BIT3
#define P2_SWITCHES (S1 | S2 | S3 | S4)





///Define functions

void screen_interrupt_handler();

void switch_init();

void led_init();

void switch_interrupt_handler();

void buzzer_init();

static char switch_update_interrupt_sense();

void led_update();

void buzzer_set_period(short cycles);

extern char updater(char value);

#endif
