#include <msp430.h>
#include <stdio.h>
#include "libTimer.h"
#include "updater.h"
#include "toy.h"

#define LED_RED BIT0
#define LED_GREEN BIT6
#define LEDS (BIT0 | BIT6)
#define S1 BIT0
#define S2 BIT1
#define S3 BIT3
#define S4 BIT2
#define P2_SWITCHES (S1 | S2 | S3 | S4)

char switch_state_down, switch_state_changed;
static short time_in_ms;
static char playTone;
//static char music[];
static int i = 0;


int main(void)

{
  time_in_ms = -1;
  playTone = 0;//used to play tone
  configureClocks();//set clocls 
  //INIT THE FEATURES OF MSP430
  buzzer_init();
  switch_init();
  led_init();
  enableWDTInterrupts();
  time_in_ms = 5000;//play time of tone

  or_sr(0x18);//Turn off the GPU.

}



void enableTone(){

  static char toneFrequencies[10] = {240,230,
				     220,210,
				     200,190,
				     180,170,
				     160,150};//Frequencies for tone.

  buzzer_set_period(toneFrequencies[i++]+90);//enable the song to be played.

  void led_cycle();
  led_cycle();//Turns on LEDS.

}

///////////////////////////////////

///FUNTIONS USED FOR BUZZERS //REUSED FROM DEMOS

///////////////////////////////////////

void buzzer_set_period(short cycles){
  CCR0 = cycles;//Cycle on.
  CCR1 = cycles >> 1;//Cycle off.

}



void buzzer_init(){
  timerAUpmode();
  P2SEL2 &= ~(BIT6 | BIT7);
  P2SEL &= ~BIT7;
  P2SEL |= BIT6;
  P2DIR = BIT6;

}

//////////////////////////////////////////



//REUSED FROM DEMOS

void switch_init(){

  P2REN |= P2_SWITCHES;//REN is turned on.
  P2OUT |= P2_SWITCHES;//OUT is set to zero.
  P2DIR &= ~P2_SWITCHES;//DIR is set to zero.
  P2IE = P2_SWITCHES;//Interrupt is turned on.

  switch_update_interrupt_sense();
  led_update();

}



static char switch_update_interrupt_sense(){
  char p1val = P2IN;
  P1IES |= (p1val & S1);
  P1IES &= (p1val | ~S1);
  return p1val;

}



void switch_interrupt_handler(){
  char p1val = switch_update_interrupt_sense();
  switch_state_down = (p1val & S1) ? 0 : 1;
  switch_state_changed = 1;
  led_update();

}

/////////////////////////////////////////

//REUSED LED FUNCTIONS

//////

void led_init(){
  P1DIR |= LEDS;
  switch_state_changed = 1;
  led_update();

}



void led_update(){//changed which led get changed
  if(switch_state_changed) {
    char ledFlags = 0;

    ledFlags |= switch_state_down ? LED_RED : 0;
    ledFlags |= switch_state_down ? 0 : LED_GREEN;

    P1OUT &= (0xff - LEDS) | ledFlags;

    P1OUT |= (ledFlags);

  }
  switch_state_changed = 0;

}



////////////////

void led_cycle(){

  P1OUT = LEDS;
  __delay_cycles(10000);//DIMS both lights
  P1OUT &= ~LED_GREEN;
  __delay_cycles(10000);//DIMS red light
  P1OUT &= ~LED_RED;
  __delay_cycles(10000);//turn both lights off

}

void screen_interrupt_handler(){
  char p2 = P2IN;
  P2IES |= (p2 & S1);
  P2IES &= (p2 | ~S1);
  switch_state_down = (p2 & S1) ? 0 : 1;
  switch_state_changed = 1;
  led_update();

}

void allOn(){//TURNS ON BORTH RED AND GREE LED
  char p2 = P2IN;
  P2IES |= (p2 & S2);
  P2IES |= (p2 | ~S2);
  char r = ~(p2 & S2);
  if(r){
    P1OUT |= LEDS;
  }
  else{
    P1OUT |= 0;
  }

}

void allOff(){//TURNS OF RED AND GREEN LED
  char p2 = P2IN;
  P2IES |= (p2 & S3);
  P2IES |= (p2 | ~S3);
  char r = ~(p2 & S3);
  if(r){
    P1OUT &= ~LEDS;
  }

}

///////////////////////////////////////

//INTERRUPT FUNCTIONS

/////////////////////////

//Interrupt for checking which switches are pressed

void

__interrupt_vec(PORT2_VECTOR) Port_2(){//@CHANGE THE ORDERING!!!

  if(P2IFG & S1){//FLIPS FROM grEEN LED TO RED
    P2IFG &= ~S1;
    screen_interrupt_handler();
  }
  else if(P2IFG & S2){// TURNS ON BOTH RED AND GREEN LED
    void allOn();
    P2IFG &= ~S2;
    allOn();
  }

  else if(P2IFG & S3){// TURNS OFF BoTH RED AND GREEN LED
    void allOff();
    P2IFG &= ~S3;
    allOff();
  }

  else if(P2IFG & S4){// HANDLES THE SOUND PLAYING FOR S4
    P2IFG &= ~S4;
    P2IES |= (P2IN & S4);
    P2IES &= (P2IN | ~S4);
    time_in_ms = (2 * 250);//2 seconds * number of interrupts per second.
    //i = 0;//can be used to randomize the sounds //changes how it sounds like
    playTone = updater(playTone);
  }
}



//interrupt for the buzzer to play song
void __interrupt_vec(WDT_VECTOR) WDT(){//
  if(time_in_ms > -1 && playTone){
    if(--time_in_ms == 0){
      buzzer_set_period(0);
      playTone = 0;
    }
    else if((time_in_ms % 50) == 0){
      void enableTone();
      enableTone();
    }
  }
}
