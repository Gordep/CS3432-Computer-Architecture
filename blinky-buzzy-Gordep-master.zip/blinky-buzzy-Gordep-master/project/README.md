To reader,

This is a simple toy that utilizes four switch buttons on the msp430.

S1 allows the LED on the toy to switch from green to read
S2 allows for both the green and red led to be on
S3 plays a simple tune (In my case the tune seems to change could not figure
out why) and the LEDs flash with the tune, and puts both LEDs off at the end of it
S4 turns off all the LEDs on the toy


Run make in project folder to load the program onto the msp430
run make clean to clean .o files the project folder





