#include "tokenizer.h"
#include <stdio.h>
#include <stdlib.h>
/*
  Author Julian Gonzalez

 */


/* Counts the number of characters in the string argument. */

int string_length(char* str){
  int length = 0;
  for(int i = 0; str[i] != '\0'; i++){ //iterates str and stops only when their is a end(0)
    length = length + 1;

  }
  return length;
}



/* Evaluates if the character c is an acceptable character for

   a token. Acceptable characters include any alphanumeric or

   special character. Unacceptable characters include any

   whitespace or control characters.

   Returns 0 if not, 1 if yes. */

char is_valid_character(char c){
  if(c > 32 && c<127){//check if char is valid using ascii values 
    return '1';
  }
  return '0';
}
/* Finds the next word in the string. 

   For example, given an input of "  my cake" the function

   should return "my cake". */

char* find_word_start(char* str){
  int pos = 0;
  while(is_valid_character(str[pos]) == '0'){//check the string and stop when a word valid or not
    pos++;
  }
  return &str[pos];
} 
/* Finds the end of current word.

   For example, given an input of "my cake" the function

   should return " cake". */

char* find_word_end(char* str){
  int end = string_length(str)-1;//start at the end of the string 
  for(int i = end;i>=0;i--){//iterate backwards and return the last word
    if(is_valid_character(str[i])=='0'){
      return &str[i];
    }
  }
  return str;
}


/* Counts the number of words in the string argument. */

int count_words(char* str){
  int iterator = 0;
  int words = 0;
  while(str[iterator] != '\0'){ //loop through the word 
    if(is_valid_character(str[iterator])=='1'){//if the word is valid just iterate while loop
      iterator++;
    }
    else{//if not valid iterate loop and add to int words 
      iterator++;
      words++;
    }
  }
  return words;
}

/* Copies the next word in str to copy. */

  void copy_word(char* str, char* copy){//replace old copy function
    int wordLength;

    char* start = find_word_start(str);//find start of word

    char* end = find_word_end(start);//find end of word 

    wordLength = end - start;//get the length of the word

    for (int i = 0; i < wordLength; i++){//iterate with word length and copy into "copy" param

      copy[i] = start[i];

    }

    //char* copy_word(char *str){

    //copies the next word in mystr

    //into new memory

    //returns pointer to there



    //1.find the size of mystr

    //2.malloc(size)

    //3.copy over myStr into new memory
}



/* Tokenizes the string argument into an array of tokens.

   For example, "hello world string" would result in:

     tokens[0] = "hello"

     tokens[1] = "world"

     tokens[2] = "string" */

  char** tokenize(char* str){
    int size = count_words(str);//num of words
    char** token = (char**)(malloc(sizeof(char*)*(size+1)));//token initialization

    for(int i = 0; i < size; i++){//for loop to put words into token
      char* wordStart = find_word_start(str);
      char* wordEnd = find_word_end(str);
      int word  = wordEnd - wordStart;
      token[i]= (char*)(malloc(sizeof(char)*(word+1)));
      copy_word(wordStart, *(token+i));
      str = wordEnd;
    }
    return token;
  }


/* Prints all tokens. */

void print_tokens(char** tokens){
  int i;
  for(i = 0; **tokens != '\0'; i++){
    printf("%s\n", tokens[i]);
  }
}

 
/* Frees all tokens and the array containing the tokens. */

void free_tokens(char** tokens){
  char** toFree = tokens;

  while(**toFree != '\0'){
    free(*tokens);
    toFree++;
  }
}

