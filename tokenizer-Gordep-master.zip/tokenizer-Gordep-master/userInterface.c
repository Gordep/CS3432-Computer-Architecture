#include <stdio.h>
#include <stdlib.h>
#include "tokenizer.h"
#include "history.h"
#include "tokenizer.c"
#include "history.c"
#define MAX 100

/*
Author Julian Gonzalez


 */

int main(){
  char buf[MAX];
  char* p;

  printf("Enter ? to exit \n");
  while(buf[0] != '?'){
    p = buf;
    printf(">");
    fgets(buf, MAX, stdin);
    printf(buf,"\n");
    printf("Length of string: %d \n", string_length(p));
    printf("0=invalid, 1=valid character: %c \n", is_valid_character(buf[0]));
    printf("Print word start:%s \n", find_word_start(p));
    printf("Print num of words %d \n", count_words(p));
    printf("Print end of word:%s \n", find_word_end(p));

    char **t = tokenize(p);
    printf("Print tokens\n");
    print_tokens(t);
    // rest of functions 
  }
   
}
