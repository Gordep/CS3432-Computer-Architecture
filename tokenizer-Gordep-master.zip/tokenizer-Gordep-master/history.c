#include <stdio.h>
#include <stdlib.h>
#include "history.h"
/*
  Author: Julian Gonzalez
*/

/* Initialize the linked list to keep the history. */

List* init_history(void){
  List* h = (List*)malloc(sizeof(List));
  return h;
}
  


/* Add a history item to the end of the list.

   List* list - the linked list

   char* str - the string to store

*/

void add_history(List* list, char* str){
  Item *n = list->root;//node 
  int iter = 0;
  if(n== NULL){
    n = malloc(sizeof(list));
    n->id = 0;
    n->str = str;
    n-> next = NULL;
    return;
  }
  while(n->next!=NULL){
    n = n->next;
    iter+=1;
  }
  n->next = malloc(sizeof(list));
  n->next->str = str;
  n->next->next = NULL;
  n->next->id = iter;
  
}


/* Retrieve the string stored in the node where Item->id == id.

   List* list - the linked list

   int id - the id of the Item to find */

char* get_history(List* list, int id){
  Item *temp = list->root;
  
  while(temp != NULL){
    if(temp->id == id){
      return (temp->str);
    }
    temp = temp->next;
  }
}


/* Print the entire contents of the list. */

void print_history(List* list){
  Item *printee = list->root;
  while(printee != NULL){ //iter through the LL
    printf("%d: %s \n",printee->id,printee->str); //print the contents of the node
    printee = printee->next;
  }
}


/* Free all Items and the List. */

void free_history(List* list);
