#ifndef OverState_included
#define OverState_included



void buzzer_init();
void buzzer_set_period(short cycles);
void gameOverSong();



#endif

