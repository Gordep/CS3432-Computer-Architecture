1. Use make in main project location then use make load in game file directory

2. To start playing either press any of the buttons on your msp430 below the
display

3. SW2 - SW3 controls the bottom paddle, while SW4 - SW5 controls the upper
paddle
